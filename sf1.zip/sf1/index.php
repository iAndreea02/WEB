<?php
session_start();

// Check if the user is logged in
if (isset($_SESSION['name'])) {
  $username = $_SESSION['name'];
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <link rel="stylesheet" href="css/stil.css">
    <!--Bara sus -->
    <title>SmartFood</title>
    <link rel="website icon" type="jpeg" 
    href="img/SmartCity.jpeg"
</head>
<body>
    <!--Header-->
    <header>
        <div class="logo">
            <img src="img/SmartCity.jpeg" style="height: 50px;width: 50px;" alt="Your Logo">
			<label for="img" style="font-size: 50px;">SmartFood<label>
        </div>

        <!--SearchBar-->
        <div class="container">
            <div class="search-container">
              <input class="input" type="text">
              <svg viewBox="0 0 24 24" class="search__icon">
                <g>
                  <path d="M21.53 20.47l-3.66-3.66C19.195 15.24 20 13.214 20 11c0-4.97-4.03-9-9-9s-9 4.03-9 9 4.03 9 9 9c2.215 0 4.24-.804 5.808-2.13l3.66 3.66c.147.146.34.22.53.22s.385-.073.53-.22c.295-.293.295-.767.002-1.06zM3.5 11c0-4.135 3.365-7.5 7.5-7.5s7.5 3.365 7.5 7.5-3.365 7.5-7.5 7.5-7.5-3.365-7.5-7.5z">
                  </path>
                </g>
              </svg>
            </div>
            </div>
       
        <nav>
            <ul>
                <li><a href="#home">Home</a></li>
                <li><a href="#about">About Us</a></li>
                <li><a href="#top10">TOP 10</a></li>
                <?php if (isset($_SESSION['name'])): ?>
            <!-- Display greeting if user is logged in -->
            <li id="greeting">Hello, <?php echo $username; ?></li>
            <li style="border: 30px;"><a href="user/logout.php">Log out</a></li>
        <?php else: ?>
            <!-- Display the Profile link if user is not logged in -->
            <li id="prof"><a href="user/index.php">Profile</a></li>
        <?php endif; ?>
            </ul>
        </nav>
    </header>
    
     <!--buton sign in- daca se da click se duge la google ca atat m a dus capul->  
     <a href="https://www.google.com">
     <button>
        <span> Sign in
        </span>
      </button>
    </a>
    
    
      <!--Imaginea de fundal-->  
    <img src="img/Whole Foods and Clean Eating.jpg" style="height:800px;width: 1500px;" alt="Poza_mancare">
    
    

    <footer>
        <p>&copy; 2024 @Pisicile-Salbatice Website. All rights reserved.</p>
    </footer>

</body>
</html>