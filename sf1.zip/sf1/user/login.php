<?php
session_start();

include('connect.php'); // Assuming this file contains your database connection code

if (isset($_POST['submit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['pass']);

    $sql = "SELECT * FROM signup WHERE name='$username'";
    $result = mysqli_query($conn, $sql);

    if ($result) {
        if ($row = mysqli_fetch_assoc($result)) {
            // Verify the password
            if (password_verify($password, $row['password'])) {
                // Password is correct, create a session
                $_SESSION['name'] = $username;
                header("Location: ../index.php"); // Redirect to a welcome page
                exit();
            } else {
                echo "Invalid password";
            }
        } else {
            echo "Username not found";
        }
    } else {
        die("Error: " . mysqli_error($conn));
    }
}

mysqli_close($conn);
?>
