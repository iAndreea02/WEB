<?php 
include("connect.php");
include("singup.php");
include("login.php");
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="prof.css">
    <style>
        h1{
            padding: 20px;
        }
        label {
            display: inline-block;
            margin-right: 10px; /* Spațiu între butoanele radio */
        }
    </style>
    <title>Modern Login Page | AsmrProg</title>
</head>

<body>
    <!-- <button style="position:fixed ; top: 10px; left: 10px; padding:10px "><a href="../index.php">Main Page</a></button> -->
    <div class="container" id="container">
    <h1>Profile</h1>
    <input type="text" class="txt"name="fullname" placeholder="Fullname"><br><br>
                
    <input type="int" class="txt"name="age" placeholder="Age"><br><br>

    <input type="int" class="txt"name="weght" placeholder="Weight"><br><br>

    <div id="buton">
    <label for="isal">Gen: </label><br>
    <label for="true">Famale</label>
    <input type="radio" id="famale" name="isg" value="famale">
    <label for="false">Male</label>
    <input type="radio" id="male" name="isg" value="male">
    <br><br>
    <label for="isal">Allergic</label><br>
    <label for="true">True</label>
    <input type="radio" id="true" name="isal" value="true">
    <label for="false">False</label>
    <input type="radio" id="false" name="isal" value="false">
    </div>
    <button id="but">
  <span class="transition"></span>
  <span class="gradient"></span>
  <span class="label">Button</span>
</button>

    </div>

    <script src="script.js"></script>
</body>

</html>