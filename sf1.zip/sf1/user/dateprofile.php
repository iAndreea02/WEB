<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname1 = "db1"; // Numele primei baze de date
$dbname2 = "db2"; // Numele celei de-a doua baze de date

// Conexiunea la prima bază de date
$conn1 = new mysqli($servername, $username, $password, $dbname1);



// Verificarea conexiunilor
if ($conn1->connect_error || $conn2->connect_error) {
    die("Conexiunea a eșuat: " . $conn1->connect_error . " / " . $conn2->connect_error);
}

// Exemplu de interogare în prima bază de date
$query1 = "SELECT id, username FROM table1";
$result1 = $conn1->query($query1);

if ($result1) {
    while ($row = $result1->fetch_assoc()) {
        // Procesează datele din prima bază de date
        echo "ID: " . $row['id'] . ", Username: " . $row['username'] . "<br>";
    }
}

// Exemplu de interogare în a doua bază de date
$query2 = "SELECT idp, fullname, age, weight FROM table2";
$result2 = $conn2->query($query2);

if ($result2) {
    while ($row = $result2->fetch_assoc()) {
        // Procesează datele din a doua bază de date
        echo "IDP: " . $row['idp'] . ", Fullname: " . $row['fullname'] . ", Age: " . $row['age'] . ", Weight: " . $row['weight'] . "<br>";
    }
}

// Închiderea conexiunilor la bazele de date
$conn1->close();
$conn2->close();
?>
